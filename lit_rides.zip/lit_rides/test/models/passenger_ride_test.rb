require 'test_helper'

class PassengerRideTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
